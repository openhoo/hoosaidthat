# HooSaidThat for Playwright

Normal Playwright tests with real screenreader actions and evidence. Supported
adapters: Orca protocol v1, independent Go HooVDA protocol v2, and real NVDA
2026.1.1 through a Windows reference oracle. The Windows runner also has a JAWS
2027 adapter for English desktop speech. See [Windows readers in Docker](docs/windows-readers.md)
for setup and the scope of the checks.
HooVDA targets the immutable `nvda-web-2026.1.1` web profile through pinned
public behavior assertions and native-Linux observations; it contains no NVDA
code or binary.

```ts
import { expect, test } from '@openhoo/hoosaidthat';

test('checkout is announced', async ({ page, screenReader }) => {
  await page.goto('/checkout');
  await screenReader.returnToPage();
  await screenReader.nextHeading();
  await expect(screenReader).toHaveSpoken(/Checkout.*heading/i);
  await expect(screenReader).toHaveBraille(/Checkout/i);

  await screenReader.focus(page.getByRole('button', { name: 'Pay now' }));
  await expect(screenReader).toHaveSpoken(/Pay now.*button/i);
});
```

**Record a mobile feature:** use `hoosaidthat-record ios` for VoiceOver or
`hoosaidthat-record android` for TalkBack. Add `--manual` to drive the device yourself, or
pass a feature scenario. Both save the device screen and its output audio. See the
[recording walkthrough](docs/mobile-recordings.md) for setup, a reusable
checkout scenario, and running an existing Android Playwright test.

Experimental Android TalkBack support connects a dedicated device or emulator
through adb and captures its text-to-speech requests. See the
[TalkBack guide](oracle/android-talkback/README.md) for setup and qualification limits.

For Apple platforms, see [VoiceOver on the Mac](#voiceover-on-the-mac) or
[VoiceOver in iPhone Simulator](#voiceover-in-iphone-simulator).

## Release state

The declared `nvda-web-2026.1.1` browser profile contains 190 unique actions.
HooVDA and real NVDA run the same command-specific semantic oracle, core web
behavior corpus, presentation-settings/reset contract, privacy checks, and
event-provenance assertions. Release qualification executes every action in all
four `en-US`/`de-DE` and desktop/laptop cells. Command shards keep each browser
session bounded without weakening total coverage.

Chrome 151's visited-link and spelling-error quick-navigation boundaries are
asserted as exact real-NVDA English/German output, not mislabeled as successful
element traversal. These gates prove the declared browser-testing profile, not
unrestricted NVDA desktop, add-on, touch, or application-specific parity.

Publishing remains an explicit tagged release operation. No unversioned npm
package or OCI image is published from normal CI.
Normal push and pull-request CI runs package checks and the small Orca image
smoke/E2E gate only. The complete HooVDA parity matrix stays local and in the
explicitly dispatched release workflow so ordinary commits do not spend hours
of hosted-runner time.
The hosted release workflow and required credentials are documented in
[`docs/releasing.md`](docs/releasing.md). It requalifies npm, HooVDA, and Orca
before publishing version-only artifacts with SBOM and provenance attestations.
Real-NVDA qualification runs separately on a trusted self-hosted KVM runner or
an operator workstation because GitHub-hosted Linux runners do not provide this
persistent licensed Windows oracle.

## Local build

HooVDA engine and Playwright runtime use separate public repositories:

```bash
git clone git@github.com:openhoo/hoovda.git ../hoovda
npm ci
npx playwright install ffmpeg
npm run image:build:hoovda
npm run image:smoke:hoovda
```

Orca remains available:

```bash
npm run image:build:orca
npm run image:smoke:orca
```

Both container paths are Linux/amd64. Normal runtime and CI require no Windows,
VM, KVM, Wine, NVDA executable, or NVDA fork. Optional real-NVDA qualification
uses the repository's Windows 11 KVM oracle:

```bash
npm run nvda:windows:doctor
npm run nvda:windows:up
npm run nvda:windows:wait
npm run nvda:windows:parity
```

Windows state, generated SSH identity, pinned host key, password, and bearer
token stay outside Git under `~/VMs/hoosaidthat-nvda`. See the
[Windows NVDA oracle guide](oracle/windows-nvda/README.md).

The npm package includes a compiled parity suite, so installed parity commands
run without a source checkout or TypeScript compiler. From a consumer project,
use `npx hoosaidthat-nvda-windows parity` for the managed Windows oracle or
`node node_modules/@openhoo/hoosaidthat/scripts/hoovda-parity.mjs en-US desktop`
for a configured HooVDA runtime image.

## Configuration

### Android TalkBack

Run real TalkBack and Chrome in a disposable Android emulator. Create the Google
Play virtual device once as described in the [TalkBack guide](oracle/android-talkback/README.md),
then run:

```bash
npm run build
npm run talkback:android:build
npm run talkback:android:run -- --avd HST_TalkBack_API35 --token-file ~/.hst/talkback-token
```

Use `--serial SERIAL` instead to attach to a device you have prepared yourself.

Consumer tests use `screenReader: 'talkback'`, `runtime: 'external'`,
`workers: 1` and the distinct `talkback-web` profile. The run command supplies
the `HOOSAIDTHAT_TALKBACK_*` endpoints and token to a child suite. Android uses
Chrome's persistent device context; see the [guide](oracle/android-talkback/README.md)
for isolation and speech-capture boundaries. The [emulator test record](docs/evidence/android-talkback-api35.md)
covers heading and button navigation, activation, and live-region announcements on
Android 15 with TalkBack 15.0 and Chrome 124 in English. Physical devices and
other versions or locales still need their own run.


```ts
import { defineConfig } from '@openhoo/hoosaidthat';

export default defineConfig({
  use: {
    video: 'on',
    trace: 'retain-on-failure',
    screenReaderOptions: {
      screenReader: 'hoovda',
      image: 'hoosaidthat-hoovda:dev',
      profile: 'nvda-web-2026.1.1',
      locale: 'en-US',
      keyboardLayout: 'desktop',
      recording: 'on',
      overlay: true,
      actionScreenshots: 'on',
    },
  },
});
```

Real NVDA uses the same fixtures against external endpoints. Set `HOOSAIDTHAT_NVDA_CONTROL_TOKEN` in the worker environment or pass a private file path as `controlTokenFile`. Playwright reporters can export literal values from project options.

```ts
export default defineConfig({
  use: {
    screenReaderOptions: {
      screenReader: 'nvda',
      runtime: 'external',
      profile: 'nvda-web-2026.1.1',
      locale: 'en-US',
      keyboardLayout: 'desktop',
      controlEndpoint: 'http://127.0.0.1:3002',
      cdpEndpoint: 'http://127.0.0.1:9224',
    },
  },
});
```

One runtime container starts per Playwright worker. Playwright connects over
CDP to Chromium inside it. Ordinary `page`, `context`, trace, screenshot, and
assertion APIs remain available. Host networking lets container Chromium reach
Linux development servers at `127.0.0.1`.

Only run trusted sites. Chromium uses `--no-sandbox`, loopback CDP, and host
networking. Screenreader control binds to loopback and requires a random bearer
token.

## Actions and evidence

For Linux runtimes, ordinary actions become complete physical X11 gestures and
pass through the AT-SPI device listener. Real NVDA delivers gestures through
NVDA's official system-test emulation boundary:

```ts
await screenReader.act('nextLandmark');
await screenReader.act('nextHeading2');
await screenReader.act('nextFormField');
await screenReader.act('activate');
await screenReader.reportDetails();
await screenReader.elementsList();
```

Find needs a query. `findText()` sends that bounded string through the v2
structured control API; subsequent `findNext` and `findPrevious` actions use
the runtime's normal gesture path:

```ts
await screenReader.findText('order total');
await screenReader.act('findNext');
await screenReader.act('findPrevious');
```

Each observation contains ordered typed events plus derived text:

```ts
const observation = await screenReader.nextHeading();
console.log(observation.speech);
console.log(observation.braille);
console.log(observation.events); // speech, braille, focus, mode, audio, lifecycle
```

For output caused by ordinary page operations:

```ts
const observation = await screenReader.observe('Open dialog', async () => {
  await page.getByRole('button', { name: 'Open' }).click();
});
```

To test an *automatic* announcement, take a fresh speech checkpoint immediately
before the triggering interaction and read from it once. For example, after
establishing that the opener has focus:

```ts
const beforeOpen = await screenReader.checkpoint();
await screenReader.activate();
const opened = await screenReader.readFrom(beforeOpen, 'First dialog focus');
expect(opened.speech).toContain('Edit profile'); // dialog context
expect(opened.speech).toContain('Cancel');       // initially focused button
await expect(page.getByRole('button', { name: 'Cancel' })).toBeFocused();
```

A later `readCurrent`, Find, or heading scan tests what the user can *request*
afterwards; it cannot establish what was announced on entry. For tab stops,
exercise both Tab and Shift+Tab, and cover the empty as well as the populated
state when content controls whether a stop exists. Take another checkpoint
for each independent change (for example, clearing one of two field errors).

Regression-test a complete stable flow with Playwright snapshots:

```ts
await screenReader.nextHeading();
await screenReader.nextFormField();
await screenReader.activate();
await expect(screenReader.regressionTranscript()).toMatchSnapshot('checkout.hoovda.txt');
```

`regressionTranscript()` removes internal page-focus setup and keeps output
correlated with each recorded action. `transcript()` remains the complete raw
flow, including browser focus transitions.

Every HooVDA test attaches:

- stable text and JSON flow transcripts;
- structured event and accessible-document JSON;
- synthesized screenreader WAV;
- container-recorded WebM with screenreader audio;
- runtime provenance;
- requested screenshots.

The page overlay shows current action, speech, and braille evidence in normal
Playwright video. HooVDA also records container A/V, so its WebM contains real
eSpeak audio synchronized to the browser display. Real NVDA uses Playwright's
browser video with the same synchronized overlay; its capture boundary is
structured presentation hooks, not acoustic Windows audio.

### Check the local HooVDA runtime before a long suite

From the installed package, run `npx hoosaidthat-hoovda-doctor`. The doctor
starts one managed runtime and reports its image ID, platform, HooSaidThat
source revision and HooVDA commit. It compares the engine pin in the installed
package with both the image label and the authenticated, running engine. It
then connects to Chromium over CDP and reads a fresh marker from a server bound
to the test host's loopback address. The process exits nonzero if any check
fails and stops its container on exit.

For a source build, use `--image <tag-or-digest> --source <full-HooSaidThat-commit>`;
`--runtime docker` and `--runtime podman` select the container engine. If your
site also needs a media server or another service, check that service from the
runtime browser before starting the suite. A successful loopback check only
proves the path it exercised.

### When the page fails to load

If a test using the `page` fixture fails, times out, or is interrupted, its
Playwright result includes `screen-reader-browser-failures.json`. It records
the first 16 document/script failures and first eight other failures, including
HTTP errors and uncaught JavaScript error types. Counts include omitted events.
Classification uses the browser's request type: an SVG requested as a
JavaScript module is a script. Each event records whether it occurred before
HooSaidThat dispatched its first reader gesture on the fixture page. This does
not track keyboards or tools controlled outside the session.

Resource IDs are comparable only within that attempt. The attachment omits URLs,
paths, query values, headers, bodies, error messages, and stacks. A recognized
file extension, the presence of an `import` query key, and the browser network
error code can help explain why a shell rendered but an expected control never
appeared. This is evidence of what the browser observed, not a determination of
which component caused a failure. A successful HTTP status also doesn't prove
a dev server supplied the expected module: compare the module the browser
actually imported (including its version query) with the installed source.

Playwright keeps this attachment with the failed attempt even if a retry passes.
For independent reruns, use distinct output directories; Playwright clears the
selected directory when a new run begins:

```bash
npx playwright test --retries=0 --output=test-results/qualify-001
npx playwright test --retries=0 --output=test-results/recheck-001 --grep 'First dialog focus'
```

Keep each result with its selected case IDs, source commit, and runtime/engine
revision. Report initial failures and subsequent passes separately. A passing
HooVDA/Chromium check does not establish the result for native Windows NVDA or
another browser.

## Annotated website reports

Set `screenReaderOptions.webReport: 'on'` to export a portable
`screen-reader-report.html` for each test. It shows the page snapshot after each
action with the actual captured screenreader speech positioned at its source
element. Click the annotation to play the original audio from that utterance.
The file embeds its images and audio and opens directly in a browser or on a
static website host.

Exact audio playback requires the updated HooVDA engine's sample index. Other
adapters and older images show speech and snapshots with audio explicitly
unavailable. See the [web report guide](docs/web-reports.md) for configuration,
export paths, and evidence boundaries.

## Element images

Focused controls:

```ts
await screenReader.captureElements([
  { name: 'email', locator: page.getByLabel('Email') },
  { name: 'pay-now', locator: page.getByRole('button', { name: 'Pay now' }) },
]);
```

Automated structural export:

```ts
await screenReader.capturePageElements({ maxPerKind: 100, screenshots: true });
```

This visits every exported structural group: headings, landmarks, buttons,
form fields and their subtypes, links, lists and list items, tables,
graphics, text paragraphs, frames, separators, block quotes, embedded objects,
annotations, spelling or grammar errors, and non-link text. It exports an image
for each observed output plus a JSON manifest. Each result includes its ordered
`screenshots` paths. `scan()` remains available for custom action loops.

## Options

- `screenReader`: `orca` (default), `hoovda`, `nvda`, `jaws`, `voiceover`, or `talkback`
- `profile`: selected from the reader; Windows uses `nvda-web-2026.1.1` or `jaws-web`
- `locale`: `en-US` or `de-DE` (JAWS: `en-US` only)
- `keyboardLayout`: `desktop` or `laptop` (JAWS: `desktop` only)
- `runtime`: `auto`, `docker`, `podman`, or `external`
- `image`: OCI image reference
- `recording`: `on` or `off`; default `on`
- `startupTimeoutMs`: default `60000`, maximum `600000`
- `actionTimeoutMs`: default `5000` for Orca and `15000` for protocol v2 readers; maximum `30000`
- `quietMs`: default `300`, maximum `5000`
- `overlay`: default `true`
- `actionScreenshots`: `off` or `on`
- `webReport`: `off` or `on`; default `off`; portable annotated HTML per test
- `keepContainer`: retain stopped container for diagnosis
- `viewport`: Xvfb dimensions; default `1280x720`
- `containerEngineArgs`: extra trusted Docker/Podman arguments; rejected for native Windows, macOS and Android readers

Externally managed runtimes require control and CDP endpoints and a control token. Supply the token in the reader’s environment variable or use `controlTokenFile` in Playwright projects. Plain HTTP endpoints must target host loopback; use HTTPS for
non-loopback endpoints, normally behind an SSH tunnel or equivalent secure
transport.

## Evidence boundary

HooVDA consumes real Chromium AT-SPI objects. It produces structured
presentation, braille translation, and eSpeak PCM from its own Go engine. This
is stronger than asserting against a browser accessibility snapshot. It still
does not certify WCAG conformance, simulate disabled people's lived experience,
or prove unrestricted NVDA parity. The passing provenance-pinned gate proves
only its declared browser-profile cases.

JAWS reports the speech text that its Remote Command Server emits. The
Windows runner checks the JAWS and Chrome versions before starting the suite.
The JAWS adapter currently supports US English and the desktop layout; it
does not capture braille or record the synthesizer's audio.

Real NVDA evidence is captured at `speech.extensions.pre_speechQueued` and
`braille.pre_writeCells`. It proves NVDA presentation requests and braille
display writes, not acoustic output or user perception. Windows is a reference
oracle; no Windows or NVDA image is published as an OCI container.

See [runtime protocol](docs/runtime-protocol.md),
[HooVDA image](images/hoovda/README.md), and
[Orca image](images/orca/README.md), and the
[Windows NVDA oracle](oracle/windows-nvda/README.md).

## VoiceOver on the Mac

For a prepared test Mac with Chrome and VoiceOver, see [running the bridge on a Mac desktop](docs/native-screen-readers.md#running-directly-on-a-test-mac).

### Isolated macOS guest

Actual VoiceOver is available with `screenReader: 'voiceover'` and the
`voiceover-web` profile. On an Apple Silicon Mac with Tart installed:

```bash
npm run build
npm run voiceover:macos:doctor
npm run voiceover:macos:run
```

For an installed package, use `npx hoosaidthat-voiceover-macos run`.
The helper provisions a pinned headless macOS guest and runs two native checks
inside it, then stops the guest. Host audio, desktop windows, clipboard and USB
passthrough are disabled. The helper leaves host VoiceOver and host settings
untouched. This desktop bridge requires macOS; a Linux container can host its client.

On November 4, 2026, VoiceOver 10 (993) / macOS 26.6.2 / Chrome 151.0.7922.34
passed heading navigation, keyboard button focus and asynchronous live-region
speech checks from an installed package. Last-phrase sampling may miss identical
consecutive phrases and phrases replaced between polls. This is bounded smoke
coverage. See [the VoiceOver guide](docs/native-screen-readers.md) for setup,
configuration, capture limits and qualification details.

## VoiceOver in iPhone Simulator

The experimental iPhone runner opens a website in Mobile Safari and checks
VoiceOver's own navigation output. An [iPhone 18 Pro simulator with iOS 27.0 and Xcode 27.1](docs/ios-voiceover.md#verification-status) spoke the test page's button and heading. To run the check:

```bash
npm run voiceover:ios:doctor
npm run voiceover:ios:run -- --udid <simulator-UDID>
```

The default check navigates between a heading and a button. To test your own
site, pass `--scenario path/to/scenario.json`. See [the iPhone guide](docs/ios-voiceover.md)
for an example, supported actions and the resulting transcript.
