# Screenreader runtime protocols

All control endpoints bind to loopback and require:

```text
Authorization: Bearer <token>
```

The runtime owns graphical Chromium. Playwright connects separately over CDP.
HooSaidThat supports legacy Orca protocol v1 plus protocol v2 implementations
for HooVDA and the real-NVDA Windows oracle.

## HooVDA protocol v2

`GET /v2/health` and `GET /v2/actions` expose immutable profile identity and
the supported semantic command catalog.

Each Playwright test owns one exclusive runtime session:

```http
POST /v2/sessions
Content-Type: application/json

{"testId":"checkout","recording":true}
```

Session endpoints:

- `GET /v2/sessions/{id}/state`
- `POST /v2/sessions/{id}/actions` with `{"command":"nextHeading"}`
- structured find input with `{"command":"find","argument":"order total"}`
- `GET /v2/sessions/{id}/events?after=12&timeoutMs=15000`
- `GET /v2/sessions/{id}/document`
- `POST /v2/sessions/{id}/finish`
- `GET /v2/sessions/{id}/artifacts/{name}`

Ordinary actions inject complete physical X11 gestures. The AT-SPI global
device listener maps that observed gesture back to the semantic command. Find
is the sole structured-input exception because its query would normally be
typed into an NVDA-owned dialog; the bounded query is delivered directly and
the response declares `"delivery":"structured"`. Other actions declare
`"delivery":"physical"`. Find-next and find-previous remain physical.

Ordered event kinds:

- `commandStarted`, `commandSettled`
- `speech` with structured speech commands
- `braille` with logical NVDA-style buffer text plus translated cells and cursor
- `focus`, `mode`, `liveRegion`
- `audio` with monotonic offset and duration

`sequence` is process-global and monotonic. Clients reject truncated history,
backward cursors, malformed UTF-8, oversized JSON, duplicate artifact names,
and artifact byte-count or SHA-256 mismatches. `monotonicNs` shares the clock used
to place synthesized PCM into the recorded timeline. An action response includes
all causally observed events after its pre-injection cursor and waits for a
bounded quiet interval.

State also exposes HooVDA browse/focus mode and `cursorInDocument`. The optional
`browse` object identifies the current virtual-buffer object and includes exact
`quickNavigationTargets` matched by HooVDA. Link objects include `visited`.
Protected object names are withheld and marked `redacted`. Document objects can
include `documentUrlSha256`, the lowercase SHA-256 digest of the exact URL
reported by AT-SPI; the raw URL is never returned. These fields let page element
export include an element already selected by `documentStart`, without guessing
from localized speech. Page-focus verification requires a runtime-native
web-content focus signal. HooSaidThat additionally matches `documentUrlSha256`
against the active Playwright page when available; a Chromium tab wrapper or an
active CDP document alone is insufficient.

Finish closes the test recording and returns SHA-256-bound artifacts:

- `screenreader-events`
- `screenreader-document` when the final accessible document is available
- `screenreader-audio`
- `screenreader-video` when recording was enabled

Clients must verify byte length and SHA-256 after download. HooSaidThat does.
Closing the page or browser context before fixture teardown can make the final
document refresh unavailable or exceed its deadline. HooVDA then omits the
document artifact and preserves the completed events, audio, and enabled video
recording. It never exports the stale cached graph as the final document.
The active-session document and state endpoints still report refresh failures.

Updated HooVDA engines include an optional `audioTimeline` array in the finished
`screenreader-events` JSON. Each entry contains `monotonicNs` (the originating
speech event timestamp), `startSample`, `sampleCount`, and `sampleRate`. Sample
positions address frames in the actual exported WAV, after recorder-origin
subtraction, sample rounding, ordering, and overlap serialization. Reports use
this index to extract original utterance clips. Runtime `audioOffsetNs` alone
is not a WAV seek offset. Engines without the index still support transcripts
and snapshots, but reports mark utterance playback unavailable.
Successful finish calls are idempotent while their artifacts remain retained,
so a client can safely retry after a lost HTTP response. HooVDA bounds retained
finished sessions to 32 and removes expired session directories.

## Orca protocol v1

Legacy endpoints remain:

- `GET /v1/health`
- `GET /v1/state`
- `GET /v1/actions`
- `POST /v1/actions`
- `GET /v1/events`

Orca events contain captured Speech Dispatcher presentation text. Protocol v1
has no per-test runtime A/V artifact lifecycle; Playwright video plus the page
overlay remains its recording path.

## Real NVDA protocol v2

The Windows oracle implements the same health, action catalog, exclusive
session, state, action, event, finish, and `screenreader-events` artifact
contracts used by the v2 client. It deliberately does not claim HooVDA's
accessible-document, synthesized-audio, or container-video artifacts.

Ordinary commands call `inputCore.manager.emulateGesture` on NVDA's main
thread and declare `"delivery":"emulated"`. Structured find is the sole
exception and declares `"delivery":"structured"`. Speech comes from
`speech.extensions.pre_speechQueued`; braille comes from
`braille.pre_writeCells` plus display dimensions. These are presentation-hook
observations, not physical-keyboard or acoustic evidence. Consecutive
byte-identical idle braille refresh writes are coalesced. NVDA's blinking
cursor overlay is normalized into stable translated cells plus the separate
cursor index. Command-caused writes and identical frames separated by any
other event remain observable.
The NVDA oracle likewise makes successful finish calls idempotent and retains
the eight most recent event artifacts.

Native focus and browser readiness remain required observations. Navigator,
review, and mouse objects can become disconnected after navigation; an
unreadable optional object is reported as `null`, and unavailable mouse
coordinates omit the mouse diagnostic. Focus roles use NVDA's stable enum names
rather than localized labels. Document focus must match the active page's title
or available URL identity. A command emits one settlement after its required
state and event-history reads succeed, or one failure settlement if they fail.

Speech, focus, live-region, and braille text identified as protected by native
focus or known source context is replaced with `[redacted]` before entering event
history or exported artifacts. Protected braille cells are removed. Missing or
failed native protection observations also withhold content; an unavailable
protection flag never permits a name read.

NVDA live-region capture observes both object handlers and the queued
presentation calls made directly by NVDAHelper's native IA2 live-region report
callback. The native callback supplies text and politeness; its processed speech
produces the semantic event at the speech queue boundary. Unrelated preceding
speech is never used to fill an object event. Command and known protection
context are preserved across the deferred queue, and focus protection is checked
again when presentation runs. This callback supplies no source object, geometry,
atomicity, relevance, or busy-state metadata. The capture attests the reported
politeness and processed output, with the protection observed for focus and any
known object-handler context; it does not attest arbitrary source protection.
Protected braille messages retain their protection across cursor and scrolling
redraws of the same message buffer. A new message receives its own protection
context, and the restored main buffer does not inherit the old message's flag.

Locale is a process boundary. The SSH controller atomically selects `en-US` or
`de-DE`, restarts the owned runtime, and starts NVDA with its official `--lang`
override. Runtime status attests that locale. Session creation fails closed when
the requested locale does not match the running process; changing gettext state
inside an already-imported NVDA process is not accepted as localization proof.

Every declared action has a semantic speech or braille oracle. Chrome for
Testing 151 exposes no visited-link target and reports spelling quick navigation
as unsupported through its NVDA accessibility backend in this isolated profile.
The four commands remain exercised, but the gate asserts their exact localized
boundary presentation instead of claiming successful traversal.

Chrome listens on guest loopback. The NVDA plugin exposes a byte-for-byte CDP
proxy to the QEMU user-network boundary. Both host mappings remain loopback
only. A separate key-only, host-key-pinned SSH control plane manages the VM;
its forced dispatcher is not part of the browser/runtime HTTP protocol.

## Android TalkBack protocol v2

The Android bridge uses the authenticated protocol v2 session/finish endpoints with
`screenReader: "talkback"`, `platform: "android"`, `profile: "talkback-web"`
and `capture: "talkback-tts-output"`. These fields are validated by the client.
Native keyboard injection and accessibility-focus actions declare
`delivery: "emulated"`. Its action catalog follows TalkBack's Default Alt
keymap and excludes unmapped NVDA actions and settings.

A separate Android instrumentation process verifies the native foreground
package and WebView focus while leaving TalkBack enabled. The capture app
records actual `TextToSpeechService` requests only from TalkBack's UID, with
generation and consecutive sequence checks. It preserves repeated utterances
and fails on loss or restart. Ordinary tests use a silent synthesis callback.
For an emulator feature movie, the helper sends TalkBack’s requests to an
installed Android voice and returns its PCM to TalkBack’s playback stream.
The recorder captures the guest’s output audio alongside its display. See the
[Android guide](../oracle/android-talkback/README.md) for prerequisites,
persistent Chrome-context limitations and the real-device smoke suite.

## Security and platform rules

- Orca and HooVDA containers are Linux/amd64; real NVDA is Windows 11 on KVM.
- Loopback control and CDP endpoints.
- Random bearer token per worker.
- One active protocol-v2 session per runtime.
- Strict JSON decoding and bounded request bodies/timeouts.
- Plain HTTP external endpoints are accepted only on host loopback; remote
  endpoints require HTTPS or a secure local tunnel.
- Normal container runtime needs no Windows, KVM, QEMU, Wine, or NVDA binary.
- The optional Windows oracle installs a hash-pinned official NVDA binary at runtime; repository and npm package contain no NVDA binary or source.
- Unknown commands and artifact names fail closed.

## VoiceOver native boundary

The `voiceover-web` profile uses a real macOS host (`platform: macos`) through an
external authenticated v2 runtime. `voiceover-last-phrase` samples VoiceOver's
native last phrase and records changes, with a 100 ms delay between completed
sample requests. Identical consecutive
phrases and overwritten samples may be lost. `voiceover-speech-output` identifies
the separate experimental streaming AT Driver boundary. Both require a native
VoiceOver process/version attestation. Unsupported commands fail explicitly.
Native AX focus and VoiceOver cursor membership are verified before web entry is
accepted. Captured speech uses `screenReaderOutput` provenance; lifecycle events
remain separate. Finished event artifacts are bound to their SHA-256 digests.
See [the VoiceOver guide](native-screen-readers.md) for setup and qualification.


## JAWS on Windows

The `jaws-web` adapter uses protocol v2. Health identifies the Windows process, browser,
`screenReader: "jaws"` and `capture: "jaws-speech-output"`. Speech events come from
`interaction.capturedOutput` in JAWS Remote Command Server. Actions advertised by
`GET /v2/actions` are delivered as emulated keyboard input. The Windows UI Automation
probe identifies which browser document has keyboard focus; its names do not become
speech events. The adapter does not infer virtual-buffer activity from keyboard
focus or speech. The state response omits `cursorInDocument`, and
`screenReader.state()` omits `virtualBufferActive`.
The adapter does not expose NVDA settings, braille cells or original
audio. See [Windows readers in Docker](windows-readers.md).

For each JAWS action, the bridge checks foreground focus (up to 10 seconds), sends
one key chord and waits for its acknowledgement (up to 10 seconds), then waits
for speech to settle (up to 15 seconds). The client's default HTTP deadline is
37 seconds including transport overhead. A shorter client `actionTimeoutMs`
does not shorten the guest's speech window. A completed action that expected speech
but received none returns `timedOut: true`. If the key acknowledgement expires,
delivery is uncertain: the bridge requires a restart and never repeats the key.
