# TalkBack on Android

Experimental real TalkBack adapter for Chrome on an explicitly selected Android
device or emulator. It uses protocol v2, the `talkback-web` profile, and the
`talkback-tts-output` capture boundary. It has no NVDA parity claim.

The Node bridge runs on the computer connected to the device through `adb`.
The screen reader and Chrome run on Android. Use `--avd` to launch and prepare
a disposable instance of a named Android Virtual Device (AVD), or `--serial` to attach to a device you prepared yourself.

## Run on an Android emulator

On the emulator host, install the Android SDK command-line tools, JDK 17+ and
Node 22+. Set `ANDROID_HOME` and `JAVA_HOME`, and put the SDK's `cmdline-tools/latest/bin`,
`platform-tools` and `emulator` directories on PATH. Use an emulator host with
hardware acceleration. The following example is for x86-64 Linux; choose an
available ABI matching your emulator host on other platforms.

```bash
sdkmanager "platform-tools" "emulator" "platforms;android-35" "build-tools;35.0.0" "system-images;android-35;google_apis_playstore;x86_64"
avdmanager create avd --name HST_TalkBack_API35 --device pixel_6 --package "system-images;android-35;google_apis_playstore;x86_64"
```

The verified Pixel 6 AVD used 4 CPU cores, 4096 MiB RAM, a 10 GiB data
partition and hardware keyboard input. To reproduce it, set
`hw.cpu.ncore=4`, `hw.ramSize=4096M`, `disk.dataPartition.size=10G` and
`hw.keyboard=yes` in the new AVD's `config.ini` before its first boot.
Use TalkBack's Default keymap with Alt as its modifier. The default smoke
suite expects an English device and reader. For a German consumer suite,
configure the base AVD's language first: `--locale de-DE` tells the bridge
which locale to report; it does not change Android or TalkBack's language.

From the HooSaidThat checkout:

```bash
npm ci
npm run build
npm run talkback:android:build
npm run talkback:android:run -- --avd HST_TalkBack_API35 --token-file ~/.hst/talkback-token
```

The CLI starts a headless instance, waits for Android to boot, checks its AVD
name, installs the two helper APKs, selects the capture engine and enables
TalkBack. The Google Play image must include Chrome and Android Accessibility
Suite. If TalkBack is absent, install it in the base AVD through Google Play
or supply a trusted, compatible standalone APK with `--talkback-apk PATH`.
The CLI does not download third-party APKs. If your image presents an onboarding
screen it cannot dismiss, complete setup once in the base AVD and close it.

With WSL2 on a KVM-enabled host, set `HST_EMULATOR_GPU=lavapipe` if
the default software renderer stalls during boot. This selects Lavapipe and
disables the guest Vulkan feature. Set `HST_EMULATOR_BIN` to override the
SDK emulator executable.

The managed instance uses `-read-only -no-snapshot`: changes made during the
test are discarded when it stops. Other connected devices keep their settings.
Use `start --avd NAME` to serve a session until Ctrl+C, or append
`-- <command> [args...]` to `run` for a consumer suite. The default `run`
checks native navigation and async live-region speech. Set `HST_TALKBACK_RESULTS`
to an absolute directory to retain the test attachments on the host.

## Record a feature with audible TalkBack

On macOS, Linux or WSL, install scrcpy (with `--require-audio`) and FFmpeg.
The Google Play API 35 image can use its stock Google voice. To use another
installed offline voice, prepare its language data first and pass
`--tts-engine its.package.name`. Set `HST_SCRCPY_BIN` or `HST_FFMPEG_BIN` if
the programs are outside PATH.

Run a custom Playwright suite using the normal HooSaidThat fixtures:

```bash
hoosaidthat-talkback-android run --avd HST_TalkBack_API35 \
  --token-file ~/.hst/talkback-token --recording artifacts/checkout.mp4 \
  -- npx playwright test --config mobile.config.ts
```

The command records the selected emulator's full display and Android output
mix while the child runs. TalkBack supplies the words, language, pitch and
rate. The test helper asks the installed Android voice to synthesize them and
returns its actual PCM for playback on TalkBack's stream. There is no external
narration or microphone input. The helper currently supports 16-bit PCM voices
for English (US) and German (Germany); it does not reproduce engine-specific
span prosody. A different voice, this relay and the emulator can affect timing.

Alongside the MP4, `artifacts/checkout.mp4.talkback.jsonl` contains TalkBack's
own synthesis requests, tagged with the Android uptime and host observation
time. Requests can be interrupted; the movie is the evidence of what played.
The exporter requires H.264 video, a non-silent guest audio track, and nonzero
device-voice PCM for a TalkBack request from this run. It refuses to overwrite
either output. A failing test may still produce evidence and keeps its failing
exit status. Only the read-only `--avd` path can select a recording voice.
For a web app served on the host, `--reverse-port PORT` routes that loopback
port through adb for this run. The child receives `ANDROID_SERIAL` so any
additional adb commands target the same emulator.

## Attach to a prepared device with `--serial`

Requirements:

- Android 14 / API 34 or newer. Emulators must expose Android's shell `uinput`
  utility for virtual keyboard input.
- Google TalkBack (`com.google.android.marvin.talkback`) enabled, its tutorial
  completed, and **Default keymap**, **Alt modifier**, default shortcuts selected
  in TalkBack's physical keyboard settings. Classic and customized keymaps are
  not supported. Configure the reader language to `en-US` or `de-DE`.
- Chrome (`com.android.chrome`) installed, its first-run prompts completed,
  and a web page foreground. Chrome variants and embedded WebViews are not
  currently supported.
- Developer options and USB debugging enabled, the host authorized, and `adb`
  on PATH. `HST_ADB_BIN` can select another executable. Wireless adb serials
  work when the device is already paired and connected.
- Node 22+ and this package's compatible Playwright version on the host.

Use a dedicated emulator or test device with a dedicated Chrome profile. The
test TTS engine is silent and stores TalkBack's synthesis requests in private
app storage. The test fixture clears Chrome cookies and storage for network
origins visited by its test pages. It does not provide a fresh browser profile
or erase captured speech on shutdown.
Context init scripts, exposed bindings and other persistent-context options
remain across tests. Use separate device/Chrome sessions when full isolation
is required. Device viewport, locale and voice settings come from Android;
desktop context emulation options are unavailable.

## Build and install the helper APKs

The capture app is a real Android `TextToSpeechService`. The probe is a separate
instrumentation app so inspection does not restart the TTS process. It connects
to `UiAutomation` with `FLAG_DONT_SUPPRESS_ACCESSIBILITY_SERVICES`, leaving
TalkBack active. No root, accessibility overlay, TalkBack patch or network
service on the device is required.

Install Android SDK `platforms;android-35` and `build-tools;35.0.0` with the
official SDK manager. Set `ANDROID_HOME` and `JAVA_HOME` to the SDK and JDK
(JDK 17+), then run from the package directory:

```bash
npm run build
npm run talkback:android:build
adb devices -l
adb -s emulator-5554 install -r oracle/android-talkback/build/hoosaidthat-capture.apk
adb -s emulator-5554 install -r oracle/android-talkback/build/hoosaidthat-probe.apk
```

Builds use the SDK's `aapt2`, D8, zipalign and apksigner directly. Both APKs are
signed and verified with a generated test key under the ignored `build/`
directory. This is a test-only debug signing key, not a release identity. Keep
it when updating an existing installation, or uninstall the old helpers first.
The npm package includes Java sources and the build command; APKs and signing
keys are excluded.

On Android, open **Settings → Text-to-speech output → Preferred engine** and
select **HooSaidThat capture TTS**. If TalkBack has an explicit engine override,
select the capture engine there as well. Resume TalkBack after changing the
engine and confirm Chrome's web content can receive accessibility focus.
Selecting this engine silences TalkBack; use a disposable emulator or arrange
another way to operate the test device during setup.

## Check and run

Replace the example serial with the exact value from `adb devices`:

```bash
npm run talkback:android:doctor -- --serial emulator-5554
npm run talkback:android:run -- --serial emulator-5554 --token-file /tmp/hst-talkback/control-token
```

`doctor` checks the Android API, installed reader/browser versions, enabled
TalkBack, selected capture engine and native Chrome window. It reports speech
as **not tested**. `run` additionally opens an owned bootstrap tab, captures a
fresh title from TalkBack, starts authenticated control, and runs the packaged
heading/button/live-region smoke tests. During cold startup the bridge can
reattach to the capture engine up to twice, with a new title each time. Once
the session starts, a capture failure invalidates it. Silent startup or failed native focus
prevents the bridge from reporting ready.

To run a consumer suite instead:

```bash
hoosaidthat-talkback-android run --serial emulator-5554 --token-file /tmp/hst-talkback/control-token -- npx playwright test
```

```ts
import { defineConfig } from '@openhoo/hoosaidthat';

export default defineConfig({
  workers: 1,
  fullyParallel: false,
  use: {
    screenReaderOptions: {
      screenReader: 'talkback',
      runtime: 'external',
      locale: 'en-US',
      keyboardLayout: 'desktop',
      webReport: 'on',
    },
  },
});
```

`run` provides `HOOSAIDTHAT_TALKBACK_CONTROL_ENDPOINT`,
`HOOSAIDTHAT_TALKBACK_CDP_ENDPOINT`, and `HOOSAIDTHAT_TALKBACK_CONTROL_TOKEN` to
its child. `start` serves those endpoints until Ctrl+C and prints the endpoint
and token-file paths, never the token. For a separately started suite, pass the
endpoints and token through `screenReaderOptions` or these environment variables.
The default host loopback ports are control **3005** and CDP **9227**. Override
them with `--control-port` and `--cdp-port`; `--locale de-DE` configures a German
bridge session. One bridge holds a host lease per explicit device serial.
Shutdown removes its own adb forward and bootstrap tab and leaves the prepared
device running. A crash can leave a stale lease; startup reports its exact path
so it can be removed after checking that the old bridge has stopped.

Host development servers are not automatically reachable as Android localhost.
Use an emulator's host gateway or create a specific `adb -s SERIAL reverse`
mapping for your application's port. The bridge does not change application
networking. With `--serial`, it also leaves accessibility and TTS settings alone.

## Actions and capture boundaries

The adapter advertises only mapped commands: Tab/Shift+Tab keyboard focus,
activation, document start/end, reading from the current location, word and
character navigation, headings (including levels 1–6), landmarks, buttons,
controls, checkboxes, combo boxes, edit fields, graphics, links, lists, list
items and tables. Structural shortcuts use TalkBack's Default Alt keymap.
`returnToPage` requests native WebView accessibility focus; `readCurrent`
clears and restores the currently focused native accessible object's focus.
Document start/end place native accessibility focus on the first/last readable
node in Chrome's web content, so navigation stays out of its toolbar. On
emulators, mapped shortcuts use Android's `uinput` tool to send virtual USB
keyboard events through TalkBack. The prepared physical-device path retains
Android shell keyboard input; it has not been qualified here.
These actions require Android to accept the focus request or keyboard input.
They do not derive announcements from DOM text. Normal Playwright locators and speech assertions remain available.

The native probe verifies the foreground package and whether native focus is
inside Chrome's WebView. It returns no input values or password text. It does
not expose an exact accessible-document URL, cursor mode, braille, NVDA
presentation settings, arbitrary find, or unmapped desktop commands.

The capture engine accepts evidence only from TalkBack's Android UID using
`SynthesisRequest.getCallerUid()`. Requests from other TTS clients are excluded.
UTF-8, multiline and identical successive utterances are preserved. The host
validates a generation ID and consecutive sequence numbers; truncation, restart,
wrong UID, oversized utterance or capacity loss makes capture fail. Old speech
is drained before a new command. Capture is bounded to approximately 2 MiB per
TTS process; restart the bridge after restarting the capture engine for a fresh
run. After a reader/probe/device failure, finish retains already collected
events with artifact integrity metadata.

TalkBack's default quiet interval is 1.5 seconds: Android can send the name,
role, and resulting live update in separate synthesis requests. For observations
of slower application updates, set `quietMs` in the fixture options.

These are actual **synthesis requests**, not proof of audible playback or
utterance completion. Outside movie mode, the test engine returns short silent PCM and does not
preserve natural voice timing. Interruptions and continuous-reading behavior
can differ from a normal voice. These text artifacts do not include a WAV or a braille display. Text/JSON transcripts, runtime identity, screenshots and annotated
HTML reports use the existing evidence path.

## Verification

`npm test` covers options, protocol identity, synthetic native bridge round trips,
capture corruption/loss, event attribution, Android gestures and CDP forwarding.
`npm run talkback:android:build` compiles both Java helpers against Android 35 and
verifies their APK signatures. These checks alone do not qualify real TalkBack
behavior. The [Android 15 emulator test record](../../docs/evidence/android-talkback-api35.md)
includes actual TalkBack speech requests from the unchanged smoke suite, run
both from a cold managed AVD and against a prepared emulator. It covers the
Google Play x86_64 API 35 revision 9 image with TalkBack 15.0.0.639625893,
Chrome 124.0.6367.219, and en-US. Physical devices, other versions and German
speech were not tested. Run the suite and retain its attachments for each
additional configuration you need to support.

Primary implementation references: Android `TextToSpeechService`,
`SynthesisRequest.getCallerUid()`, `UiAutomation` and `AccessibilityNodeInfo`;
Google TalkBack's `DefaultKeyComboModel.java` in `google/talkback`; Chrome's
Android remote-debugging protocol; and the installed compatible Playwright
Android implementation.
